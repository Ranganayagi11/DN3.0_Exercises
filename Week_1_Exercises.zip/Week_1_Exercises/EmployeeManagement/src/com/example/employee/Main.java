package com.example.employee;
public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem();

        // Add Employees
        ems.addEmployee(new Employee(1, "Alice", "Developer", 70000));
        ems.addEmployee(new Employee(2, "Bob", "Manager", 90000));
        ems.addEmployee(new Employee(3, "Charlie", "Analyst", 60000));

        // Traverse Employees
        System.out.println("All Employees:");
        ems.traverseEmployees();

        // Search for an Employee
        System.out.println("\nSearch Employee with ID 2:");
        Employee emp = ems.searchEmployee(2);
        System.out.println(emp != null ? emp : "Employee not found");

        // Delete an Employee
        System.out.println("\nDelete Employee with ID 3:");
        boolean isDeleted = ems.deleteEmployee(3);
        System.out.println(isDeleted ? "Employee deleted" : "Employee not found");

        // Traverse Employees after Deletion
        System.out.println("\nAll Employees after Deletion:");
        ems.traverseEmployees();
    }
}
