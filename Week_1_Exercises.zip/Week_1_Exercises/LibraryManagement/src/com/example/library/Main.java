package com.example.library;
public class Main {
    public static void main(String[] args) {
        Library library = new Library(10);

        // Add Books
        library.addBook(new Book(1, "To Kill a Mockingbird", "Harper Lee"));
        library.addBook(new Book(2, "1984", "George Orwell"));
        library.addBook(new Book(3, "The Great Gatsby", "F. Scott Fitzgerald"));

        // Linear Search by Title
        System.out.println("Linear Search for '1984':");
        Book book1 = library.linearSearchByTitle("1984");
        System.out.println(book1 != null ? book1 : "Book not found");

        // Binary Search by Title
        System.out.println("Binary Search for '1984':");
        Book book2 = library.binarySearchByTitle("1984");
        System.out.println(book2 != null ? book2 : "Book not found");

        // Linear Search for a book that doesn't exist
        System.out.println("Linear Search for 'Moby Dick':");
        Book book3 = library.linearSearchByTitle("Moby Dick");
        System.out.println(book3 != null ? book3 : "Book not found");

        // Binary Search for a book that doesn't exist
        System.out.println("Binary Search for 'Moby Dick':");
        Book book4 = library.binarySearchByTitle("Moby Dick");
        System.out.println(book4 != null ? book4 : "Book not found");
    }
}

