package com.ecommerce;

import java.util.Arrays;
import java.util.Comparator;

public class SearchAlgorithms {

    public static Product linearSearch(Product[] products, String targetProductName) {
        for (Product product : products) {
            if (product.getProductName().equalsIgnoreCase(targetProductName)) {
                return product;
            }
        }
        return null;
    }

    public static Product binarySearch(Product[] products, String targetProductName) {
        Arrays.sort(products, Comparator.comparing(Product::getProductName));

        int left = 0;
        int right = products.length - 1;

        while (left <= right) {
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getProductName().compareToIgnoreCase(targetProductName);

            if (comparison == 0) {
                return products[mid];
            } else if (comparison < 0) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Product[] products = {
            new Product("1", "Laptop", "Electronics"),
            new Product("2", "Smartphone", "Electronics"),
            new Product("3", "Table", "Furniture"),
            new Product("4", "Chair", "Furniture"),
            new Product("5", "Headphones", "Electronics")
        };

        // Linear search
        System.out.println("Linear Search Result:");
        Product result = linearSearch(products, "Table");
        System.out.println(result != null ? result : "Product not found");

        // Binary search
        System.out.println("Binary Search Result:");
        result = binarySearch(products, "Table");
        System.out.println(result != null ? result : "Product not found");
    }
}
