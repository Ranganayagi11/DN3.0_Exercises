package com.example.task;
public class Main {
    public static void main(String[] args) {
        TaskLinkedList taskList = new TaskLinkedList();

        // Add Tasks
        taskList.addTask(new Task(1, "Design database schema", "In Progress"));
        taskList.addTask(new Task(2, "Develop login feature", "Not Started"));
        taskList.addTask(new Task(3, "Write unit tests", "Completed"));

        // Traverse Tasks
        System.out.println("All Tasks:");
        taskList.traverseTasks();

        // Search for a Task
        System.out.println("\nSearch Task with ID 2:");
        Task task = taskList.searchTask(2);
        System.out.println(task != null ? task : "Task not found");

        // Delete a Task
        System.out.println("\nDelete Task with ID 3:");
        boolean isDeleted = taskList.deleteTask(3);
        System.out.println(isDeleted ? "Task deleted" : "Task not found");

        // Traverse Tasks after Deletion
        System.out.println("\nAll Tasks after Deletion:");
        taskList.traverseTasks();
    }
}

