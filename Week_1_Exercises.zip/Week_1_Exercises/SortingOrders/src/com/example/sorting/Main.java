package com.example.sorting;

public class Main {
    public static void main(String[] args) {
        Order[] orders = {
                new Order(1, "Alice", 150.0),
                new Order(2, "Bob", 250.0),
                new Order(3, "Charlie", 100.0),
                new Order(4, "David", 200.0)
        };

        System.out.println("Unsorted Orders:");
        for (Order order : orders) {
            System.out.println(order);
        }

        // Test Bubble Sort
        Order[] bubbleSortedOrders = orders.clone();
        BubbleSort.bubbleSort(bubbleSortedOrders);
        System.out.println("\nBubble Sorted Orders:");
        for (Order order : bubbleSortedOrders) {
            System.out.println(order);
        }

        // Test Quick Sort
        Order[] quickSortedOrders = orders.clone();
        QuickSort.quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
        System.out.println("\nQuick Sorted Orders:");
        for (Order order : quickSortedOrders) {
            System.out.println(order);
        }
    }
}

