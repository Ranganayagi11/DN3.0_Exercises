package com.example.financial;
import java.util.HashMap;
import java.util.Map;

public class FinancialForecasting {

    private static Map<Integer, Double> memo = new HashMap<>();

    public static double calculateFutureValue(double presentValue, double growthRate, int years) {
        // Base case: if years is 0, return the present value
        if (years == 0) {
            return presentValue;
        }
        // Check if result is already computed
        if (memo.containsKey(years)) {
            return memo.get(years);
        }
        // Recursive case: calculate future value for one less year and apply growth rate
        double futureValue = calculateFutureValue(presentValue, growthRate, years - 1) * (1 + growthRate);
        // Store the result in memo
        memo.put(years, futureValue);
        return futureValue;
    }

    public static void main(String[] args) {
        double presentValue = 1000.0; // initial amount
        double growthRate = 0.05; // 5% annual growth rate
        int years = 10; // number of years into the future

        double futureValue = calculateFutureValue(presentValue, growthRate, years);
        System.out.println("The future value is: " + futureValue);
    }
}
